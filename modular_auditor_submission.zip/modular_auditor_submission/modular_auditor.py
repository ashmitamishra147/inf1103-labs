def get_valid_input():
    """Ask the user for a delivery quantity and validate it."""
    while True:
        user_input = input("Enter stock quantity (or 'quit' to finish): ")

        if user_input.lower() == "quit":
            return "quit"

        try:
            quantity = int(user_input)

            if quantity < 0:
                print("Invalid input. Please enter a non-negative stock quantity.")
                continue

            return quantity

        except ValueError:
            print("Invalid input. Please enter a whole number.")


def process_delivery(current_total, new_value):
    """Add the new delivery to the current inventory total."""
    return current_total + new_value


def calculate_tax(amount):
    """Calculate 10% tax on a delivery."""
    return amount * 0.10


def generate_report(total_units, failed_attempts):
    """Print the final audit report."""
    print("\n--- Inventory Audit Report ---")
    print(f"Total Deliveries Processed: {total_units}")
    print(f"Number of Failed/Rejected Entries: {failed_attempts}")


# Main program
total_inventory = 0
total_deliveries = 0
total_rejected = 0

while True:
    quantity = get_valid_input()

    if quantity == "quit":
        break

    total_inventory = process_delivery(total_inventory, quantity)
    tax = calculate_tax(quantity)

    total_deliveries += 1

    print(f"Added {quantity} items to inventory.")
    print(f"Total inventory: {total_inventory}")
    print(f"Tax for this delivery: {tax:.2f}")

generate_report(total_deliveries, total_rejected)